Task 1
~ 3h


Principiul solutiei este urmatorul:

1. Citirea site-urilor si adaugarea lor in memorie.
2. Afisarea site-urilor.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Task 2
~ 4h 


Principiul soultiei este urmatorul:

1. Citirea site-urilor si adaugarea lor in memorie.
2. Determinarea selectiei de cautare.
3. Sortarea site-urilor care corespund selectiei de cautare.
4. Afisarea site-urilor mentionate.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Task 3
~ 4h

Principiul solutiei este urmatorul:

1. Citirea site-urilor si adaugarea lor in memorie.
2. Determinarea selectiei de cautare (cu secventa si cuvant de exclus, daca acestea exista).
3. Sortarea site-urilor care corespund selectiei de cautare.
4. Afisarea site-urilor mentionate.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Task 4
~ 3h


Principiul solutiei este urmatorul:

1. Citirea site-urilor si adaugarea lor in memorie.
2. Verificarea site-urilor si determinarea indicilor.
3. Calcularea checksum-ului pentru fiecare dintre site-urile gasite.
4. Afisarea verificarilor.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Task 5
~ 8h


Principiul solutiei este urmatorul:

Exista 4 pagini - first_page (1), search_page (2), search_query (3), print_page(4), pe fiecare
adaugandu-se legenda. Trecerea de pe o pagina pe alta se poate face conform enuntului:

1 -> 2
2 -> 3
3 -> 4, 3 -> 2
4 -> 3

Ciclarea prin pagina de rezultate se face cu ajutorul tastelor KEY_UP si KEY_DOWN
si alegerea site-ului de afisat se realizeaza prin apasarea tastei "ENTER".